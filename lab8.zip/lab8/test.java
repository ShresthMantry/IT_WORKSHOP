public class test {
    public static void main(String[] args) {
        String s = "123";
        int a = Integer.valueOf(s);
        a++;
        System.out.println(a);
    }
}
